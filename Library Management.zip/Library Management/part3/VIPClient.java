package iLibrary.part3;

public class VIPClient extends Client {
    public VIPClient(int ID, String name, String email) {
        super(ID, name, email);
    }
}
