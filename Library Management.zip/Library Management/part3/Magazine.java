package iLibrary.part3;

public class Magazine extends LibraryItem {
    private int yearOfPublication;
    private int issue;

    public Magazine(int ID, String title, int yearOfPublication, int issue, String section) {
        super(ID, title, section);
        this.yearOfPublication = yearOfPublication;
        this.issue = issue;
    }

    public int getYearOfPublication() {
        return yearOfPublication;
    }

    public void setYearOfPublication(int yearOfPublication) {
        this.yearOfPublication = yearOfPublication;
    }

    public int getIssue() {
        return issue;
    }

    public void setIssue(int issue) {
        this.issue = issue;
    }
}
