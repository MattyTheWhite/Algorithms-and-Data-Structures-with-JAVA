package iLibrary.part3;

public class BluRay extends LibraryItem {

    private int yearOfPublication;

    public BluRay(int ID, String title, int yearOfPublication, String section) {
        super(ID, title, section);
        this.yearOfPublication = yearOfPublication;
    }

    public int getYearOfPublication() {
        return yearOfPublication;
    }

    public void setYearOfPublication(int yearOfPublication) {
        this.yearOfPublication = yearOfPublication;
    }
}
