package iLibrary.part3;

import iLibrary.structures.*;

public class MyLibrary implements ILibraryManagement {
    private int lastID = 1;
    // We use a simple universal system to assign IDs, so each client and item has a unique ID
    private Tree items;
    private Vector itemsVector;
    private Tree clients;
    private Graph libraryGraph;

    public MyLibrary() {
        // The tree data structures make it more efficient to search for an item or client
        // Wherever that's not possible we implement linear search on a vector
        items = new Tree();
        clients = new Tree();
        libraryGraph = new Graph();
        itemsVector = new Vector(1000);
    }


    @Override
    public int addBook(String author, String title, int yearOfPublication, String section) {
        Book book = new Book(lastID, title, author, yearOfPublication, section);
        lastID++;
        items.insert(book);
        itemsVector.addLast(book);
        return book.getID();
    }

    @Override
    public int addMagazine(String title, int yearOfPublication, int issue, String section) {
        Magazine magazine = new Magazine(lastID, title, yearOfPublication, issue, section);
        lastID++;
        items.insert(magazine);
        itemsVector.addLast(magazine);
        return magazine.getID();
    }

    @Override
    public int addBlueRay(String title, int yearOfPublication, String section) {
        BluRay br = new BluRay(lastID, title, yearOfPublication, section);
        lastID++;
        items.insert(br);
        itemsVector.addLast(br);
        return br.getID();
    }

    @Override
    public int addCD(String author, String title, int yearOfPublication, String section) {
        CD cd = new CD(lastID, title, author, yearOfPublication, section);
        lastID++;
        items.insert(cd);
        itemsVector.addLast(cd);
        return cd.getID();
    }

    @Override
    public int addClient(String name, String email) {
        RegularClient client = new RegularClient(lastID, name, email);
        lastID++;
        clients.insert(client);
        return client.getID();
    }

    @Override
    public int addVIPClient(String name, String email) {
        VIPClient client = new VIPClient(lastID, name, email);
        lastID++;
        clients.insert(client);
        return client.getID();
    }

    @Override
    public void printAllPublications() {
        // traverse the tree and print each item
        items.traverseInOrder();

    }

    @Override
    public void printAllClients() {
        // traverse the tree and print each item
        clients.traverseInOrder();
    }

    // search and return publication object based on its attributes
    // for each of these methods we create a dummy object to find the
    // corresponding object in the tree

    private Book searchBook(String author, String title) {
        return (Book) items.find(new Book(0, title, "", 0, ""));
    }

    public Magazine searchMagazine(String title, int yearOfPublication, int issue) {
        return (Magazine) items.find(new Magazine(0, title, 0, 0, ""));
    }

    public BluRay searchBluRay(String title, int yearOfPublication) {
        return (BluRay) items.find(new BluRay(0, title, 0, ""));
    }

    public CD searchCD(String author, String title) {
        return (CD) items.find(new CD(0, title, "", 0, ""));
    }

    public Client searchClient(int id) {
        Client dummy = new Client(id, "", "");
        return (Client) clients.find(dummy);
    }

    @Override
    public int borrowBook(int client, String author, String title) {
        Book b = searchBook(author, title);
        Client c = searchClient(client);
        b.borrowItem(c);
        return b.getID();
    }

    @Override
    public int lookAtMagazine(int client, String title, int yearOfPublication, int issue) {
        Magazine m = searchMagazine(title, yearOfPublication, issue);
        Client c = searchClient(client);
        m.borrowItem(c);
        return m.getID();
    }

    @Override
    public int borrowBlueRay(int client, String title, int yearOfPublication) {
        BluRay b = searchBluRay(title, yearOfPublication);
        Client c = searchClient(client);
        b.borrowItem(c);
        return b.getID();
    }

    @Override
    public int borrowCD(int client, String author, String title) {
        CD cd = searchCD(author, title);
        Client c = searchClient(client);
        cd.borrowItem(c);
        return c.getID();
    }

    public LibraryItem searchItem(int id) {
        // Here we have trouble using same function, because here we have to search by ID
        // instead of title, and we can only use one to compare leaves in the tree
        // , so we use a linear search instead, if both of the method signatures for
        // borrowing and returning would have been the same, we could re-use the same
        // tree structure and achieve O(log N)
        for (int i = 0; i < itemsVector.size(); i++) {
            Object it = itemsVector.get(i);
            LibraryItem li = (LibraryItem) it;
            if (li.getID() == id)
                return li;
        }
        return null;
    }

    @Override
    public int returnItem(int publicationID) {
        LibraryItem i = searchItem(publicationID);
        return i.returnItem();
    }

    @Override
    public void addSection(String name) {
        libraryGraph.addNode(name);
    }

    @Override
    public void connectSections(String section1, String section2) {
        // add each section to the other one's adjacency list
        libraryGraph.addEdge(section1, section2);
        libraryGraph.addEdge(section2, section1);
    }

    @Override
    public void findShortestPath(int publicationID, String startSection) {
        // this method uses a breadth first search with a frontier queue to find a shortest path
        // between start section and the section where the item is located
        Queue f = new Queue();
        Dictionary parent = new Dictionary();

        String start = startSection;
        String end = searchItem(publicationID).getSection();
        f.push(start);
        while (!f.empty()) {
            Object currObj = f.pop();
            String currStr = (String) currObj;
            if (currStr == end) {
                printPath(parent, start, end);
                //System.out.println("found a way");
                return;
            } else {
                Graph.Node curr = libraryGraph.findNode(currStr);
                Vector neighbors = curr.getNeighbors();
                for (int i = 0; i < neighbors.size(); i++) {
                    Object neighbor = neighbors.get(i);
                    String child = (String) neighbor;
                    if (!parent.containsKey(child)) {
                        parent.add(child, (String) curr.getLabel());
                        f.push(child);
                    }
                }
            }
        }
        // we reach here when f is empty, no more nodes to check
        System.out.println("The section where the publication is located is not connected to the start section");
    }

    public void printPath(Dictionary parent, String start, String end) {
        String curr = end;
        Vector p = new Vector(100);
        while (curr != start) {
            //System.out.println(curr);
            p.addFirst(curr);
            Object o = parent.find(curr);
            curr = (String) o;
        }
        p.addFirst(curr);

        for (int i = 0; i < p.size(); i++) {
            Object v = p.get(i);
            System.out.print((String) v + " ");
        }
        System.out.println();
    }
}