package iLibrary.part3;

public class Main {

    public static void main(String[] args) {
	// write your code here
        MyLibrary myLibrary = new MyLibrary();

        // expected = 1
        System.out.println(myLibrary.addClient("Simon", "simon@vub.be"));

        // expected = 2
        System.out.println(myLibrary.addClient("Emy", "emy@vub.be"));

        //expected = 3
        System.out.println(myLibrary.addClient("Louis", "louis@vub.be"));

        // expected = 4
        System.out.println(myLibrary.addVIPClient("Fabien", "fabien@vub.be"));

        // expected = 5
        System.out.println(myLibrary.addVIPClient("Antony", "antony@vub.be"));

        myLibrary.addSection("A1");
        myLibrary.addSection("A2");
        myLibrary.addSection("A3");
        myLibrary.addSection("B1");
        myLibrary.addSection("B2");
        myLibrary.addSection("B3");
        myLibrary.addSection("C1");
        myLibrary.addSection("C2");
        myLibrary.addSection("C3");

        myLibrary.connectSections("A1", "A2");
        myLibrary.connectSections("A2", "A3");
        myLibrary.connectSections("A1", "B1");
        myLibrary.connectSections("B1", "B2");
        myLibrary.connectSections("A3", "B3");
        myLibrary.connectSections("A3", "C3");
        myLibrary.connectSections("B3", "B2");


        // expected = 6
        System.out.println(myLibrary.addBook("Jules Verne", "Around the World in Eighty Days",
                1872, "A1"));

        // expected = 7
        System.out.println(myLibrary.addBook("James Joyce", "Ulysses",
                1920, "A2"));

        // expected = 8
        System.out.println(myLibrary.addBook("Homer", "Iliad",
                1800, "C3"));

                System.out.println();

        myLibrary.printAllClients();

        System.out.println();

        myLibrary.printAllPublications();

        System.out.println(myLibrary.borrowBook(1, "Homer", "Iliad"));

        //expected = 8
        System.out.println(myLibrary.borrowBook(2, "Homer", "Iliad"));

        //expected = 8
        System.out.println(myLibrary.borrowBook(5, "Homer", "Iliad"));

        //expected = 8
        System.out.println(myLibrary.borrowBook(3, "Homer", "Iliad"));

        //expected = 8
        System.out.println(myLibrary.borrowBook(4, "Homer", "Iliad"));

        //expected = 5
        System.out.println(myLibrary.returnItem(8));

        //expected = 4
        System.out.println(myLibrary.returnItem(8));

        //expected = 2
        System.out.println(myLibrary.returnItem(8));

        //expected = 3
        System.out.println(myLibrary.returnItem(8));

        //expected = 0
        System.out.println(myLibrary.returnItem(8));


        // expected = A1 A2 A3 C3
        myLibrary.findShortestPath(8, "A1");
        // expected = B2 B3 A3 C3
        myLibrary.findShortestPath(8, "B2");
        // expected = B3 A3 A2
        myLibrary.findShortestPath(7, "B3");

    }
}
