package iLibrary.part3;

import iLibrary.structures.Queue;

class LibraryItem implements Comparable{

    private int ID;
    private String title;
    private boolean isAvailable;
    private Client borrower;
    private String section;

    // each item has two FIFO queues, one for regular clients and one for VIPs
    // alternative implementation: create a queue of queues, which can more easily
    // handle big number of classes
    private Queue regularWaitingList;
    private Queue vipWaitingList;


    public LibraryItem(int ID, String title, String section) {
        this.ID = ID;
        this.title = title;
        this.isAvailable = true;
        regularWaitingList = new Queue();
        vipWaitingList = new Queue();
        this.section = section;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void addToRegularWaitingList(RegularClient c){
        regularWaitingList.push(c);
    }

    public void addToVIPWaitingList(VIPClient c){
        vipWaitingList.push(c);
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public Client getBorrower() {
        return borrower;
    }

    public void setBorrower(Client borrower) {
        this.borrower = borrower;
    }

    public void borrowItem(Client c){
        // if the item is available, let the client borrow it, otherwise add them to the corresponding queue
        if (isAvailable){
            setBorrower(c);
            isAvailable = false;
        }
        else {
            if (c instanceof VIPClient)
                vipWaitingList.push((VIPClient) c);
            else
                regularWaitingList.push((RegularClient) c);
        }
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public int returnItem(){

        if (vipWaitingList.empty() && regularWaitingList.empty()){
            // if both queues are empty, set the item as available
            setBorrower(null);
            setAvailable(true);
            return 0;
        }

        else if (vipWaitingList.empty()){
            // if only VIP list is empty, give the item to the next person in regular queue
            Object newBorrower = regularWaitingList.pop();
            setBorrower((RegularClient)newBorrower);
            return ((RegularClient)newBorrower).getID();
        }

        else {
            // if VIP list is not empty, give the item to the next person in VIP queue
            Object newBorrower = vipWaitingList.pop();
            setBorrower((VIPClient)newBorrower);
            return ((VIPClient)newBorrower).getID();
        }
    }

    @Override
    public int compareTo(Object o) {
        LibraryItem i = (LibraryItem) o;
        return this.getTitle().compareTo(i.getTitle());
    }

    @Override
    public String toString() {
        return this.title;
    }
}
