package iLibrary.part3;

public class RegularClient extends Client {
    public RegularClient(int ID, String name, String email) {
        super(ID, name, email);
    }
}
