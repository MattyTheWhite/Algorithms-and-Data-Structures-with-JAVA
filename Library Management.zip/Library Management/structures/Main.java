package iLibrary.structures;

public class Main {

    public static void main(String[] args) {
        Vector v = new Vector(20);
        v.addFirst(10);
        v.addFirst(20);
        v.addLast(30);
        v.contains(10);
        v.removeFirst();
        v.removeLast();
        for (int i = 0; i < v.size(); i++) {
            System.out.println(v.get(i));
        }

    }

}
