package iLibrary.structures;

public class Dictionary {
	private class DictionaryPair implements Comparable {
		private Object key;
		private Object value;

		public DictionaryPair(Object key, Object value) {
			this.key = key;
			this.value = value;
		}

		public Object getKey() {
			return this.key;
		}

		public void setKey(Object key) {
			this.key = key;
		}

		public Object getValue() {
			return this.value;
		}

		public void setValue(Object value) {
			this.value = value;
		}

		public int compareTo(Object o) {
			Comparable k = (Comparable) key;
			return k.compareTo(o);
		}
	}

	private Vector data;

	public Dictionary() {
		data = new Vector(100);
	}

	public void add(Object key, Object value) {
		data.addLast(new DictionaryPair(key, value));
	}

	public int findPosition(Object key) {
		for (int i = 0; i < data.size(); i++) {
			Object o = data.get(i);
			DictionaryPair p = (DictionaryPair) o;
			if (p.getKey() == key)
				return i;
		}
		return -1;
	}

	public Object find(Object key) {
		int i = findPosition(key);
		if (i >= 0) {
            Object o = data.get(i);
            DictionaryPair p = (DictionaryPair) o;
            return p.getValue();
        }
		return null;
	}

	public void removeKey(Object key) {
		int i = findPosition(key);
		data.remove(i);
	}

	public int size() {
		return data.size();
	}

    public boolean containsKey(Object o){
        return (findPosition(o) >= 0);
    }

}