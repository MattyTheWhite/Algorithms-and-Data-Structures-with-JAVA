package iLibrary.structures;

public class Matrix
{
	// some appropriate private members.
	
	private Vector data;
	public Matrix(int nrNodes)
	{
		data = new Vector(nrNodes);
		for(int i = 0; i < nrNodes; i++) {
			Vector col = new Vector(nrNodes);
			for(int j = 0;j < nrNodes ; j++) {
				col.addLast(0);
			}
			data.addLast(col);
		}
	}

	public void set(int row, int col, Comparable weight)
	{
		((Vector) data.get(col)).set(row,weight);
	}

	public Comparable get(int row, int col)
	{
		return (Comparable) ((Vector) data.get(col)).get(row);
	}
}